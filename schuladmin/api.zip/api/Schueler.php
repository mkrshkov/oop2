<?php

class Schueler
{

}