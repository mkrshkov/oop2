<?php
class Config {
    const DBHOST = '127.0.0.1';
    const DBUSER = 'root';
    const DBPASSWORD = '';
    const DBNAME = 'schuladmin';
}

?>