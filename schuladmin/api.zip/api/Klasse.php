<?php

class Klasse
{

}